//Mariana de Oliveira - 2410320
package com.mycompany.projquitanda;

public class Verdura extends Produto {

    // atributos
    private boolean folhas;
    private boolean picados;

    // getters e setters
    public boolean isFolhas() {
        return this.folhas;
    }

    public boolean getFolhas() {
        return this.folhas;
    }

    public void setFolhas(boolean folhas) {
        this.folhas = folhas;
    }

    public boolean isPicados() {
        return this.picados;
    }

    public boolean getPicados() {
        return this.picados;
    }

    public void setPicados(boolean picados) {
        this.picados = picados;
    }
}