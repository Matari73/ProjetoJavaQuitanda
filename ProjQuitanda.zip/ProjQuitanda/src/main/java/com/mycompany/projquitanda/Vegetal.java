//Mariana de Oliveira - 2410320
package com.mycompany.projquitanda;

public class Vegetal extends Produto{

    // atributos
    private boolean saladaPronta;
    private boolean picados;

    // getters e setters
    public boolean isSaladaPronta() {
        return this.saladaPronta;
    }

    public boolean getSaladaPronta() {
        return this.saladaPronta;
    }

    public void setSaladaPronta(boolean saladaPronta) {
        this.saladaPronta = saladaPronta;
    }

    public boolean isPicados() {
        return this.picados;
    }

    public boolean getPicados() {
        return this.picados;
    }

    public void setPicados(boolean picados) {
        this.picados = picados;
    }
}