//Mariana de Oliveira - 2410320
package com.mycompany.projquitanda;

import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class BdQuitanda{
    private Quitanda quit;
    private List<Quitanda> bdQuit = new ArrayList<Quitanda>();
    
//=================== Início Singleton ===============
        private static BdQuitanda bdQuitUnico;
        
        BdQuitanda(){
        
        }
        public static BdQuitanda getGerQuit(){
            if(bdQuitUnico == null){
                bdQuitUnico = new BdQuitanda();
            }
            return bdQuitUnico;
        }
//==================== Fim Singleton =================
        public List<Quitanda> getBdQuit(){
            return bdQuit;
        }
        
    public Quitanda cadQuit(Quitanda quit){

	if(consQuitCnpj(quit)== null){
		bdQuit.add(quit);
		return quit;
        }
	else{
            return null;
	}
    }//fim cadQuit
    
    public Quitanda consQuitCnpj(Quitanda quit){
	for(int i = 0; i < bdQuit.size(); i++){
            if(quit.getCNPJ() == bdQuit.get(i).getCNPJ()){
		return bdQuit.get(i);
            }
	}
        return null;
    }//fim consQuitCnpj
    
    public Quitanda removeQuitCnpj(Quitanda quit){
        Quitanda quit1 = consQuitCnpj(quit);
        if(quit1 != null){
            bdQuit.remove(quit1);
            return null;
	}
	else{
            return quit;
        }	
    }//fim removeQuitCnpj
    
    public Quitanda atualizaQuitCnpj(Quitanda quit){
	for(int i = 0; i < bdQuit.size(); i++){
            if(quit.getCNPJ() == bdQuit.get(i).getCNPJ()){
                String nome = JOptionPane.showInputDialog(null, "Informe o novo NOME", "Atualização", JOptionPane.QUESTION_MESSAGE);
                quit.setNome(nome);
                int CNPJ = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o novo CNPJ", "Atualização", JOptionPane.QUESTION_MESSAGE));
                quit.setCNPJ(CNPJ);
                double caixa = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o novo valor do CAIXA", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                quit.setCaixa(caixa);
		bdQuit.set(i, quit);  
                return bdQuit.get(i);
            }
	}
        return null;
    }//fim atualizaQuitCnpj
    
}
