//Mariana de Oliveira - 2410320
package com.mycompany.projquitanda;

import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class BdFruta{
    private Fruta frut;
    private List<Fruta> bdFrut = new ArrayList<Fruta>();
//=================== Início Singleton ===============
        private static BdFruta bdFrutUnico;
        
        BdFruta(){
        
        }
        public static BdFruta getGerFrut(){
            if(bdFrutUnico == null){
                bdFrutUnico = new BdFruta();
            }
            return bdFrutUnico;
        }
//==================== Fim Singleton =================
        public List<Fruta> getBdFrut(){
            return bdFrut;
        }
        
    public Fruta cadFrut(Fruta frut){

	if(consFrutCod(frut)== null){
		bdFrut.add(frut);
		return frut;
        }
	else{
            return null;
	}
    }//fim cadFrut
    
    public Fruta consFrutCod(Fruta frut){
	for(int i = 0; i < bdFrut.size(); i++){
            if(frut.getCodigo() == bdFrut.get(i).getCodigo()){
		return bdFrut.get(i);
            }
	}
        return null;
    }//fim consFrutCod
    
    public Fruta removeFrutCod(Fruta frut){
        Fruta frut1 = consFrutCod(frut);
        if(frut1 != null){
            bdFrut.remove(frut1);
            return null;
	}
	else{
            return frut;
        }	
    }//fim removeFrutCod
    
    public Fruta atualizaFrutCod(Fruta frut){
	for(int i = 0; i < bdFrut.size(); i++){
            if(frut.getCodigo() == bdFrut.get(i).getCodigo()){
                String nome = JOptionPane.showInputDialog(null, "Informe o novo NOME", "Atualização", JOptionPane.QUESTION_MESSAGE);
                frut.setNome(nome);
                int codigo = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o novo CODIGO", "Atualização", JOptionPane.QUESTION_MESSAGE));
                frut.setCodigo(codigo);
                double valorCompraFornecedor = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o novo VALOR DE COMPRA ATRAVES DO FORNECEDOR", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                frut.setValorCompraFornecedor(valorCompraFornecedor);
                double porcentagemDeLucro = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe a nova PORCENTAGEM DE LUCRO", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                frut.setPorcentagemDeLucro(porcentagemDeLucro);
                double valorDaVenda = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o novo VALOR DE VENDA", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                frut.setValorDaVenda(valorDaVenda);
                boolean vendidoPorPeso = Boolean.parseBoolean(JOptionPane.showInputDialog(null, "Informe se o produto é VENDIDO POR PESO: true - false", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                frut.setVendidoPorPeso(vendidoPorPeso);
                boolean suco = Boolean.parseBoolean(JOptionPane.showInputDialog(null, "Informe se o produto é SUCO: true - false", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                frut.setSuco(suco);
                boolean semente = Boolean.parseBoolean(JOptionPane.showInputDialog(null, "Informe se o produto é SEMENTE: true - false", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                frut.setSemente(semente);
                boolean picados = Boolean.parseBoolean(JOptionPane.showInputDialog(null, "Informe se o produto é PICADO: true - false", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                frut.setPicados(picados);
                
		bdFrut.set(i, frut);  
                return bdFrut.get(i);
            }
	}
        return null;
    }//fim atualizaFrutCod
}
