//Mariana de Oliveira - 2410320
package com.mycompany.projquitanda;

import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class BdVegetal{
    private Vegetal veg;
    private List<Vegetal> bdVeg = new ArrayList<Vegetal>();
//=================== Início Singleton ===============
        private static BdVegetal bdVegUnico;
        
        BdVegetal(){
        
        }
        public static BdVegetal getGerVeg(){
            if(bdVegUnico == null){
                bdVegUnico = new BdVegetal();
            }
            return bdVegUnico;
        }
//==================== Fim Singleton =================
        public List<Vegetal> getBdVeg(){
            return bdVeg;
        }
        
    public Vegetal cadVeg(Vegetal veg){

	if(consVegCod(veg)== null){
		bdVeg.add(veg);
		return veg;
        }
	else{
            return null;
	}
    }//fim cadVeg
    
    public Vegetal consVegCod(Vegetal veg){
	for(int i = 0; i < bdVeg.size(); i++){
            if(veg.getCodigo() == bdVeg.get(i).getCodigo()){
		return bdVeg.get(i);
            }
	}
        return null;
    }//fim consVegCod
    
    public Vegetal removeVegCod(Vegetal veg){
        Vegetal veg1 = consVegCod(veg);
        if(veg1 != null){
            bdVeg.remove(veg1);
            return null;
	}
	else{
            return veg;
        }	
    }//fim removeVegCod
    
    public Vegetal atualizaVegCod(Vegetal veg){
	for(int i = 0; i < bdVeg.size(); i++){
            if(veg.getCodigo() == bdVeg.get(i).getCodigo()){
                String nome = JOptionPane.showInputDialog(null, "Informe o novo NOME", "Atualização", JOptionPane.QUESTION_MESSAGE);
                veg.setNome(nome);
                int codigo = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o novo CODIGO", "Atualização", JOptionPane.QUESTION_MESSAGE));
                veg.setCodigo(codigo);
                double valorCompraFornecedor = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o novo VALOR DE COMPRA ATRAVES DO FORNECEDOR", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                veg.setValorCompraFornecedor(valorCompraFornecedor);
                double porcentagemDeLucro = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe a nova PORCENTAGEM DE LUCRO", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                veg.setPorcentagemDeLucro(porcentagemDeLucro);
                double valorDaVenda = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o novo VALOR DE VENDA", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                veg.setValorDaVenda(valorDaVenda);
                boolean vendidoPorPeso = Boolean.parseBoolean(JOptionPane.showInputDialog(null, "Informe se o produto é VENDIDO POR PESO: true - false", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                veg.setVendidoPorPeso(vendidoPorPeso);
                boolean saladaPronta = Boolean.parseBoolean(JOptionPane.showInputDialog(null, "Informe se o produto é SALADA PRONTA: true - false", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                veg.setSaladaPronta(saladaPronta);
                boolean picados = Boolean.parseBoolean(JOptionPane.showInputDialog(null, "Informe se o produto é PICADO: true - false", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                veg.setPicados(picados);
		bdVeg.set(i, veg);  
                return bdVeg.get(i);
            }
	}
        return null;
    }//fim atualizaVegCod
}
