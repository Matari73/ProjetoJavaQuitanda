//Mariana de Oliveira - 2410320
package com.mycompany.projquitanda;

public abstract class Produto {

    //atributos
    private int codigo;
    private String codigoAux;
    private String nome;
    private double valorCompraFornecedor;
    private boolean vendidoPorPeso; // se for false é vendido por unidade
    private double porcentagemDeLucro; // porcentagem acrescentada ao valor de compra
    private double valorDaVenda;

    // getters e setters
    public int getCodigo() {
        return this.codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getCodigoAux() {
        return this.codigoAux;
    }

    public void setCodigoAux(String codigoAux) {
        this.codigoAux = codigoAux;
    }


    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getValorCompraFornecedor() {
        return this.valorCompraFornecedor;
    }

    public void setValorCompraFornecedor(double valorCompraFornecedor) {
        this.valorCompraFornecedor = valorCompraFornecedor;
    }

    public boolean isVendidoPorPeso() {
        return this.vendidoPorPeso;
    }

    public boolean getVendidoPorPeso() {
        return this.vendidoPorPeso;
    }

    public void setVendidoPorPeso(boolean vendidoPorPeso) {
        this.vendidoPorPeso = vendidoPorPeso;
    }

    public double getPorcentagemDeLucro() {
        return this.porcentagemDeLucro;
    }

    public void setPorcentagemDeLucro(double porcentagemDeLucro) {
        this.porcentagemDeLucro = porcentagemDeLucro;
    }

    public double getValorDaVenda() {
        return this.valorDaVenda;
    }

    public void setValorDaVenda(double valorDaVenda) {
        this.valorDaVenda = valorDaVenda;
    }
    
}