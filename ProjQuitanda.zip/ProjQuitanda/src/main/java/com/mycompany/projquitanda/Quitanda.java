//Mariana de Oliveira - 2410320
package com.mycompany.projquitanda;

public class Quitanda {

    // atributos
    private String nome;
    private int CNPJ;
    private double caixa = 0.0;
    private double caixaAux = 0.0;
    private double valorAuxiliar = 0.0;

    // objetos
    Fruta fru = new Fruta();
    Vegetal veg = new Vegetal();
    Verdura ver = new Verdura();

    // getters e setters
    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCNPJ() {
        return this.CNPJ;
    }

    public void setCNPJ(int CNPJ) {
        this.CNPJ = CNPJ;
    }

    public double getCaixa() {
        return this.caixa;
    }

    public void setCaixa(double caixa) {
        this.caixa = caixa;
    }

    public double getCaixaAux() {
        return this.caixaAux;
    }

    public void setCaixaAux(double caixa) {
        this.caixa = caixa;
    }
}