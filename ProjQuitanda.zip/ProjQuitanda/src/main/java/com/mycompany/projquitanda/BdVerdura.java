//Mariana de Oliveira - 2410320
package com.mycompany.projquitanda;

import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class BdVerdura{
    private Verdura ver;
    private List<Verdura> bdVer = new ArrayList<Verdura>();
//=================== Início Singleton ===============
        private static BdVerdura bdVerUnico;
        
        BdVerdura(){
        
        }
        public static BdVerdura getGerVer(){
            if(bdVerUnico == null){
                bdVerUnico = new BdVerdura();
            }
            return bdVerUnico;
        }
//==================== Fim Singleton =================
        public List<Verdura> getBdVer(){
            return bdVer;
        }
        
    public Verdura cadVer(Verdura ver){

	if(consVerCod(ver)== null){
		bdVer.add(ver);
		return ver;
        }
	else{
            return null;
	}
    }//fim cadVer
    
    public Verdura consVerCod(Verdura ver){
	for(int i = 0; i < bdVer.size(); i++){
            if(ver.getCodigo() == bdVer.get(i).getCodigo()){
		return bdVer.get(i);
            }
	}
        return null;
    }//fim consVerCod
    
    public Verdura removeVerCod(Verdura ver){
        Verdura ver1 = consVerCod(ver);
        if(ver1 != null){
            bdVer.remove(ver1);
            return null;
	}
	else{
            return ver;
        }	
    }//fim removeVerCod
    
    public Verdura atualizaVerCod(Verdura ver){
	for(int i = 0; i < bdVer.size(); i++){
            if(ver.getCodigo() == bdVer.get(i).getCodigo()){
                String nome = JOptionPane.showInputDialog(null, "Informe o novo NOME", "Atualização", JOptionPane.QUESTION_MESSAGE);
                ver.setNome(nome);
                int codigo = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o novo CODIGO", "Atualização", JOptionPane.QUESTION_MESSAGE));
                ver.setCodigo(codigo);
                double valorCompraFornecedor = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o novo VALOR DE COMPRA ATRAVES DO FORNECEDOR", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                ver.setValorCompraFornecedor(valorCompraFornecedor);
                double porcentagemDeLucro = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe a nova PORCENTAGEM DE LUCRO", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                ver.setPorcentagemDeLucro(porcentagemDeLucro);
                double valorDaVenda = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o novo VALOR DE VENDA", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                ver.setValorDaVenda(valorDaVenda);
                boolean vendidoPorPeso = Boolean.parseBoolean(JOptionPane.showInputDialog(null, "Informe se o produto é VENDIDO POR PESO: true - false", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                ver.setVendidoPorPeso(vendidoPorPeso);
                boolean folhas = Boolean.parseBoolean(JOptionPane.showInputDialog(null, "Informe se o produto é de FOLHAS: true - false", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                ver.setFolhas(folhas);
                boolean picados = Boolean.parseBoolean(JOptionPane.showInputDialog(null, "Informe se o produto é PICADO: true - false", "Atualização", JOptionPane.QUESTION_MESSAGE));          
                ver.setPicados(picados);
		bdVer.set(i, ver);  
                return bdVer.get(i);
            }
	}
        return null;
    }//fim atualizaVerCod
}
