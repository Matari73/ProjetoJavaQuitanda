//Mariana de Oliveira - 2410320
package com.mycompany.projquitanda;

public class Fruta extends Produto {

    // atributos
    private boolean suco;
    private boolean semente;
    private boolean picados;

    // getters e setters
    public boolean isSuco() {
        return this.suco;
    }

    public boolean getSuco() {
        return this.suco;
    }

    public void setSuco(boolean suco) {
        this.suco = suco;
    }

    public boolean isSemente() {
        return this.semente;
    }

    public boolean getSemente() {
        return this.semente;
    }

    public void setSemente(boolean semente) {
        this.semente = semente;
    }

    public boolean isPicados() {
        return this.picados;
    }

    public boolean getPicados() {
        return this.picados;
    }

    public void setPicados(boolean picados) {
        this.picados = picados;
    }
}